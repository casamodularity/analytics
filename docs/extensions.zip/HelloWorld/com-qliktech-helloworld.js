﻿define( [
],
/**
* @owner Enter you name here (xxx)
*/
function ( ) {

	return {
		paint: function ($element) {
			$element.html( "Hello world!!" );
		}
	};

} );
