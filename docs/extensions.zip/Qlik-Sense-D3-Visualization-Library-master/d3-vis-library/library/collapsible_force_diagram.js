var viz = function($element, layout, _this) {
	var id = senseUtils.setupContainer($element,layout,"d3vl_collapsible_force"),
		ext_width = $element.width(),
		ext_height = $element.height();

	var data = layout.qHyperCube.qDataPages[0].qMatrix;
	/*
	data.forEach(function(d) {
		d.size = d.measure(1).qNum;
	});
*/

	var dim_count = layout.qHyperCube.qDimensionInfo.length;

	var json = {name: layout.title, children: senseD3.createFamily(data,dim_count)};

	var w = ext_width,
	    h = ext_height,
	    node,
	    link,
	    root;

	var force = d3.layout.force()
	    .on("tick", tick)
	    .charge(function(d) { return d._children ? -d.size : -30; })
	    .linkDistance(function(d) { return d.target._children ? 80 : 30; })
	    .size([w, h]);

	var radius = d3.scale.linear()
		.domain(d3.extent(data,function(d) {return d.measure(1).qNum;}))
		.range([5,10]);

	var vis = d3.select("#" + id).append("svg")
	    .attr("width", w)
	    .attr("height", h);

	root = json;
	root.fixed = true;
	root.x = w/2;
	root.y = h/2 - 80;
	update();

	function update() {
	  var nodes = flatten(root),
	      links = d3.layout.tree().links(nodes);

	  // Restart the force layout.
	  force
	      .nodes(nodes)
	      .links(links)
	      .start();

	  // Update the links…
	  link = vis.selectAll("line.link")
	      .data(links, function(d) { return d.target.id; });

	  // Enter any new links.
	  link.enter().insert("svg:line", ".node")
	      .attr("class", "link")
	      .attr("x1", function(d) { return d.source.x; })
	      .attr("y1", function(d) { return d.source.y; })
	      .attr("x2", function(d) { return d.target.x; })
	      .attr("y2", function(d) { return d.target.y; });

	  // Exit any old links.
	  link.exit().remove();

	  // Update the nodes…
	  node = vis.selectAll("circle.node")
	      .data(nodes, function(d) { return d.id; })
	      .style("fill", color);

	  node.transition()
	      .attr("r", function(d) { return d.children ? 4.5 : radius(d.size); });

		var depth;
		function traverse(thing){
		    if (thing.children){
		        depth++;
		        traverse(thing.children[0]);
		    }
		}

	  // Enter any new nodes.
	  node.enter().append("svg:circle")
          .each(function(d){
            depth = 1;
            traverse(d);
            d.depth = depth;

            d.classDim = d.depth <= dim_count ? layout.qHyperCube.qDimensionInfo[dim_count - d.depth].qFallbackTitle.replace(/\s+/g, '-') : "-";
            d.cssID = d.name.replace(/\s+/g, '-');
          })
          .attr("class", function(d) { return "node " + d.classDim; })
          .attr("id", function(d) { return d.cssID; })
	      .attr("cx", function(d) { return d.x; })
	      .attr("cy", function(d) { return d.y; })
	      .attr("r", function(d) { return d.children ? 4.5 : radius(d.size); })
	      .style("fill", color)
	      .on("click", click)
          .on("mouseover", function(d){
            d3.selectAll($("."+d.classDim+"#"+d.cssID)).classed("highlight",true);
	      	d3.selectAll($("."+d.classDim+"[id!="+d.cssID+"]")).classed("dim",true);
	      	d3.selectAll($("circle"+"[id!="+d.cssID+"]")).classed("dim",true);
          })
          .on("mouseout", function(d){
            d3.selectAll($("."+d.classDim+"#"+d.cssID)).classed("highlight",false);
	      	d3.selectAll($("."+d.classDim+"[id!="+d.cssID+"]")).classed("dim",false);
	      	d3.selectAll($("circle"+"[id!="+d.cssID+"]")).classed("dim",false);
          })
	      .call(force.drag)
	      .append("title")
	      .text(function(d) {
	      	return "Name: " + d.name + " \nValue: " + d.size;
	      });

	  // Exit any old nodes.
	  node.exit().remove();
	}

	function tick() {
	  link.attr("x1", function(d) { return d.source.x; })
	      .attr("y1", function(d) { return d.source.y; })
	      .attr("x2", function(d) { return d.target.x; })
	      .attr("y2", function(d) { return d.target.y; });

	  node.attr("cx", function(d) { return d.x; })
	      .attr("cy", function(d) { return d.y; });
	}

	// Color leaf nodes orange, and packages white or blue.
	function color(d) {
	  return d._children ? "#3182bd" : d.children ? "#c6dbef" : "#fd8d3c";
	}

	// Toggle children on click.
	function click(d) {
	  if (d.children) {
	    d._children = d.children;
	    d.children = null;
	  } else {
	    d.children = d._children;
	    d._children = null;
	  }
	  update();
	}

	// Returns a list of all nodes under the root.
	function flatten(root) {
	  var nodes = [], i = 0;

	  function recurse(node) {
	    if (node.children) node.size = node.children.reduce(function(p, v) { return p + recurse(v); }, 0);
	    if (!node.id) node.id = ++i;
	    nodes.push(node);
	    return node.size;
	  }

	  root.size = recurse(root);
	  return nodes;
	}

}