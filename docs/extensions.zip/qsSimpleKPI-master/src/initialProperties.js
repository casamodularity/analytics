export default {
  version : 1.1,
  qHyperCubeDef: {
    qDimensions: [],
    qMeasures: [],
    qInitialDataFetch: [{
      qWidth: 100,
      qHeight: 100
    }]
  },
  options: {}
}
