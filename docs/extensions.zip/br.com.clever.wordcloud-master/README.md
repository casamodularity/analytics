# br.com.clever.wordcloud
Qlik Sense Word Cloud extension
This extension intends to cover the need of including word clouds into Qlik Sense

#### General Settings - Add ons
- Orientation
- Start Angle
- End Angle
- Font Max Size
- Font Min Size
- Scale
- Scale Color
- Enable Custom Range. You can Specify a specific range of colors
- From
- To


![alt tag](https://cloud.githubusercontent.com/assets/9040310/5868637/8c9dc184-a293-11e4-8bfb-1308a1aa1fa9.PNG)

![Specific Range of Colors](/preview.png?raw=true "Specific Range of Colors")

[Download zip file](https://github.com/cleveranjos/br.com.clever.wordcloud/archive/master.zip)