define( [], function () {
	'use strict';
	
	// *****************************************************************************
	// Dimensions & Measures
	// *****************************************************************************
	var dimensions = {
		uses: "dimensions",
		min: 1
	};
		
	var measures = {
		uses: "measures",
		min: 0,
		max: 1
	};
	
	// *****************************************************************************
	// Appearance section
	// *****************************************************************************
	var appearanceSection = {
		uses: "settings"
	};
	
	// *****************************************************************************
	// R functions category section
	// *****************************************************************************
	var categoryItem = {
		ref: 'props.category',
		label: "Category",
		type: "string",
		component: "dropdown",
		options: 
		[{
		  value: "summary",
		  label: "Summary"
		},{
		  value: "correlation",
		  label: "Correlation"
		},{
		  value: "model",
		  label: "Model"
		},{
		  value: "cluster",
		  label: "Cluster"
		},{
		  value: "anova",
		  label: "ANOVA"
		},{
		  value: "manova",
		  label: "MANOVA"
		},{
		  value: "regression",
		  label: "Regression"
		},{
		  value: "ttest",
		  label: "T-Test"
		},{
		  value: "ftest",
		  label: "F-Test"
		}],
		defaultValue: "summary"
	};
	
	// *****************************************************************************
	// Summary functions section
	// *****************************************************************************
	var summaryItem = {
		ref: 'props.summary',
		label: "Report",
		type: "string",
		component: "dropdown",
		options: 
		[{
		  value: "summary",
		  label: "Summary"
		 },{
		   value: "describe",
		   label: "Describe"
		 },{
		   value: "basics",
		   label: "Basics"
		 },{
		   value: "kurtosis",
		   label: "Kurtosis"
		 },{
		   value: "skewness",
		   label: "Skewness"
		 },{
		   value: "missing",
		   label: "Show Missing"
		 },{
		   value: "crosstab",
		   label: "Cross Tab"
		 }],
		 defaultValue: "summary",
		 show: function ( data ) {
			return data.props.category === 'summary';
		}
	};
	
	// *****************************************************************************
	// Distribution functions section
	// *****************************************************************************
	var distributionItem = {
		type: "items",
		label: "Report",
		items: {
			groupby: {
				ref: "props.dist.groupby",
				label: "Group by",
				type: "string",
				expression: "optional"
			},
			numericAnnotate: {
				ref: "props.dist.annotate",
				type: "boolean",
				label: "Numeric Annotate",
				defaultValue: false
			},
			benfordsBars: {
				ref: "props.dist.bars",
				type: "boolean",
				label: "Benfords Bars",
				defaultValue: false
			},
			startingDigit: {
				ref: "props.dist.startingDigit",
				type: "integer",
				label: "Starting Digit",
				defaultValue: "1",
				max: "9"
			},
			totalDigits: {
				ref: "props.dist.totalDigits",
				type: "integer",
				label: "Number of Digits",
				defaultValue: "1",
				max: "2"
			},
			method: {
			  ref: "props.dist.method",
			  type: "string",
			  component: "buttongroup",
			  label: "",
			  options: 
			    [{
					value: "abs",
					label: "abs"
			  	},{
					value: "positive",
					label: "+ve"
			  	},{
					value: "negative",
					label: "-ve"
			  	}],
			  defaultValue: "abs"
			}
		},
		 show: function ( data ) {
			return data.props.category === 'distribution';
		}
	};

	// *****************************************************************************
	// Correlation functions section
	// *****************************************************************************
	var correlationItem = {
		ref: 'props.correlation',
		type: "items",
		label: "Report",
		items: {
			ordered: {
				ref: "props.corr.ordered",
				type: "boolean",
				label: "Ordered",
				defaultValue: false
			},
			missing: {
				ref: "props.corr.missing",
				type: "boolean",
				label: "Missing Explore",
				defaultValue: false
			},
			hierarchial: {
				ref: "props.corr.hierarchial",
				type: "boolean",
				label: "Hierarchial",
				defaultValue: false
			},
			method: {
				ref: "props.corr.method",
				type: "string",
				component: "dropdown",
				label: "Method",
				options: 
				[{ value: "pearson",
				   label: "Pearson"
				},{
				   value: "kendall",
				   label: "Kendall"
				},{
				   value: "spearman",
				   label: "Spearman"
				}],
				defaultValue: "pearson"
			}
		},
		show: function ( data ) {
			return data.props.category === 'correlation';
		}
	};
	
	// *****************************************************************************
	// Model functions section
	// *****************************************************************************
	var modelItem = {
		ref: 'props.model',
		label: "Report",
		type: "string",
		component: "dropdown",
		options: 
		[{
		  value: "tree",
		  label: "Decision Tree"
		 },{
		   value: "forest",
		   label: "Forest"
		 },{
		   value: "boost",
		   label: "Boost"
		 },{
		   value: "svm",
		   label: "SVM"
		 },{
		   value: "linear",
		   label: "Linear"
		 },{
		   value: "neural",
		   label: "Neural Net"
		 },{
		   value: "survival",
		   label: "Survival"
		 }],
		 defaultValue: "tree",
		 show: function ( data ) {
			return data.props.category === 'model';
		}
	};
	
	// *****************************************************************************
	// Tree function options section
	// *****************************************************************************
	var treeItem = {
		label: "Options",
		type: "items",
		items: {
			algorithm: {
			  ref: "props.tree.algorithm",
			  type: "string",
			  component: "buttongroup",
			  label: "",
			  options: 
			    [{
					value: "traditional",
					label: "Traditional"
			  	},{
					value: "conditional",
					label: "Conditional"
			  	}],
			  defaultValue: "traditional"
			},
			minSplit: {
				ref: "props.tree.minSplit",
				type: "integer",
				label: "Min Split",
				defaultValue: "20"
			},
			minBucket: {
				ref: "props.tree.minBucket",
				type: "integer",
				label: "Min Bucket",
				defaultValue: "7"
			},
			maxDepth: {
				ref: "props.tree.maxDepth",
				type: "integer",
				label: "Max Depth",
				defaultValue: "30",
				max: "30"
			},
			complexity: {
				ref: "props.tree.complexity",
				type: "number",
				label: "Complexity",
				defaultValue: "0.0100",
				max: "1.0000"
			},
			prior: {
				ref: "props.tree.prior",
				type: "string",
				label: "Priors"
			},
			lossMatrix: {
				ref: "props.tree.lossMatrix",
				type: "string",
				label: "Loss Matrix"
			},
			missing: {
				ref: "props.tree.missing",
				type: "boolean",
				label: "Include Missing"
			}
		},
		show: function ( data ) {
			return (data.props.category === 'model' && data.props.model === 'tree');
		}
	};
	
	// *****************************************************************************
	// Forest function options section
	// *****************************************************************************
	var forestItem = {
		label: "Options",
		type: "items",
		items: {
			algorithm: {
			  ref: "props.forest.algorithm",
			  type: "string",
			  component: "buttongroup",
			  label: "",
			  options: 
			    [{
					value: "traditional",
					label: "Traditional"
			  	},{
					value: "conditional",
					label: "Conditional"
			  	}],
			  defaultValue: "traditional"
			},
			noOfTrees: {
				ref: "props.forest.noOfTrees",
				type: "integer",
				label: "Number of Trees",
				defaultValue: "510"
			},
			noOfVariables: {
				ref: "props.forest.noOfVariables",
				type: "integer",
				label: "Number of Variables",
				defaultValue: "3"
			},
			size: {
				ref: "props.forest.size",
				type: "string",
				label: "Sample Size"
			},
			impute: {
				ref: "props.tree.impute",
				type: "boolean",
				label: "Impute",
				defaultValue: true
			},
			plot: {
			  ref: "props.forest.plot",
			  type: "string",
			  component: "buttongroup",
			  label: "",
			  options: 
			    [{
					value: "importance",
					label: "Importance"
			  	},{
					value: "rules",
					label: "Rules"
			  	},{
					value: "errors",
					label: "Errors"
			  	},{
					value: "oobroc",
					label: "OOB ROC"
			  	}]
			}
		},
		show: function ( data ) {
			return (data.props.category === 'model' && data.props.model === 'forest');
		}
	};
	
	// *****************************************************************************
	// Cluster functions section
	// *****************************************************************************
	var clusterItem = {
		ref: 'props.cluster',
		label: "Report",
		type: "string",
		component: "dropdown",
		options: 
		[{
		  value: "kmeans",
		  label: "KMeans"
		 },{
		   value: "ewkm",
		   label: "Ewkm"
		 },{
		   value: "hierarchical",
		   label: "Hierarchical"
		 },{
		   value: "bicluster",
		   label: "BiCluster"
		 }],
		 defaultValue: "kmeans",
		 show: function ( data ) {
			return data.props.category === 'cluster';
		}
	};
	
	// *****************************************************************************
	// KMeans function options section
	// *****************************************************************************
	var kMeansItem = {
		label: "Options",
		type: "items",
		items: {
			noOfClusters: {
				ref: "props.kmeans.noOfClusters",
				type: "integer",
				label: "Number of Clusters",
				defaultValue: "10"
			},
			rescale: {
				ref: "props.kmeans.rescale",
				type: "boolean",
				label: "Re-Scale",
				defaultValue: true
			},
			useHClust: {
				ref: "props.kmeans.useHClust",
				type: "boolean",
				label: "Use HClust Centers",
				defaultValue: false
			},
			iterate: {
				ref: "props.kmeans.iterate",
				type: "boolean",
				label: "Iterate Cluster",
				defaultValue: false
			},
			stats: {
				ref: "props.kmeans.stats",
				type: "boolean",
				label: "Stats",
				defaultValue: false
			},
			plot: {
			  ref: "props.kmeans.plot",
			  type: "string",
			  component: "buttongroup",
			  label: "",
			  options: 
			    [{
					value: "data",
					label: "Data"
			  	},{
					value: "discriminant",
					label: "Discriminant"
			  	}]
			}
		},
		show: function ( data ) {
			return (data.props.category === 'cluster' && (data.props.cluster === 'kmeans' || data.props.cluster === 'ewkm'));
		}
	};
	
	// *****************************************************************************
	// Hierarchical function options section
	// *****************************************************************************
	var hierarchicalItem = {
		label: "Options",
		type: "items",
		items: {
			distance: {
				ref: "props.hierarchical.distance",
				type: "string",
				label: "Distance",
				component: "dropdown",
				options: 
				[{
				  value: "euclidean",
				  label: "euclidean"
				},{
				  value: "maximum",
				  label: "maximum"
				},{
				  value: "manhattan",
				  label: "manhattan"
				},{
				  value: "canberra",
				  label: "canberra"
				},{
				  value: "binary",
				  label: "binary"
				},{
				  value: "pearson",
				  label: "pearson"
				},{
				  value: "correlation",
				  label: "correlation"
				},{
				  value: "spearman",
				  label: "spearman"
				}],
				defaultValue: "euclidean"
			},
			agglomerate: {
				ref: "props.hierarchical.agglomerate",
				type: "string",
				label: "Agglomerate",
				component: "dropdown",
				options: 
				[{
				  value: "complete",
				  label: "complete"
				},{
				  value: "ward",
				  label: "ward"
				},{
				  value: "single",
				  label: "single"
				},{
				  value: "average",
				  label: "average"
				},{
				  value: "mcquitty",
				  label: "mcquitty"
				},{
				  value: "median",
				  label: "median"
				},{
				  value: "centroid",
				  label: "centroid"
				}],
				defaultValue: "ward"
			},
			noOfProcessors: {
				ref: "props.hierarchical.noOfProcessors",
				type: "integer",
				label: "number of Processors",
				defaultValue: "1"
			},
			noOfClusters: {
				ref: "props.hierarchical.noOfClusters",
				type: "integer",
				label: "Number of Clusters",
				defaultValue: "10"
			},
		   	plot: {
				ref: "props.hierarchical.plot",
				type: "string",
				component: "buttongroup",
				label: "",
				options: 
				  [{
					  value: "dendrogram",
					  label: "Dendrogram"
				  },{
					  value: "data",
					  label: "Data"
				  },{
					  value: "discriminant",
					  label: "Discriminant"
				  }]
			  }
		},
	  	show: function ( data ) {
			return (data.props.category === 'cluster' && data.props.cluster === 'hierarchical');
	  	}
	};
		
	var reportSection = {
		type: "items",
		label: "Report Options",
		items: {
			categoryItem: categoryItem,
			summaryItem: summaryItem,
			distributionItem: distributionItem,
			correlationItem: correlationItem,
			modelItem: modelItem,
			treeItem: treeItem,
			forestItem: forestItem,
			clusterItem: clusterItem,
			kMeansItem: kMeansItem,
			hierarchicalItem: hierarchicalItem
		}
	};
	
	// *****************************************************************************
	// Main properties panel definition
	// *****************************************************************************
	return {
		type: "items",
		component: "accordion",
		items: {
			dimensions: dimensions,
			measures: measures,
			reportSection: reportSection,
			appearanceSection: appearanceSection
		}
	};
		
});