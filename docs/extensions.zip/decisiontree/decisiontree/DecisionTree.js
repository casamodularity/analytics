define(["qlik", "./d3", "css!./DecisionTree.css"],
	function (qlik, d3) {
		"use strict";

		function draw(el, raw) {

			var root = d3.hierarchy(raw);
			var size = el.getBoundingClientRect();
			el.innerHTML = `
    <svg width='${size.width}' height='${size.height}'>
      <g class='tree-container' transform='translate(120, 0)'></g>
    </svg>
  `

			var tree = d3.tree()
				.size([size.height, size.width - 200]);

			var g = d3.select('.tree-container');
			//console.log(root);
			tree(root);

			var link = g.selectAll(".link")
				.data(root.descendants().slice(1))
				.enter().append("path")
				.attr("class", "link")
				.attr("d", diagonalX2);

			var node = g.selectAll(".node")
				.data(root.descendants())
				.enter().append("g")
				.attr("class", function (d) { return "node" + (d.children ? " node--internal" : " node--leaf"); })
				.attr("transform", function (d) { return "translate(" + d.y + "," + d.x + ")"; })

			node.append("circle")
				.attr("r", 40);

			node.append("text")
				.attr("dy", 3)
				.attr("x", function (d) { return -60; })
				.style("text-anchor", function (d) { return "end" })
				.text(function (d) { return d.data.var !== '<leaf>' ? d.data.description : '' });

			node.append("text")
				.attr("dy", (d) => d.parent ? -5 : 4)
				.attr("x", function (d) { return -60 })
				.style("text-anchor", function (d) { return "end"; })
				.text(function (d) { return d.data.fork });

			node.append("text")
				.attr('class', 'rate')
				.attr("dy", 6)
				//.attr("x", function(d) { return d.children ? -8 : 8; })
				//.style("text-anchor", function(d) { return d.children ? "end" : "start"; })
				.style("text-anchor", 'middle')
				.text(function (d) { return d.data.yval2[0][4] * 100 + '%' });
		};
		function diagonalX(d) {
			return "M" + d.y + "," + d.x
				+ "C" + (d.parent.y + 100) + "," + d.x
				+ " " + (d.parent.y + 100) + "," + d.parent.x
				+ " " + d.parent.y + "," + d.parent.x;
		};

		function diagonalX2(d) {
			return "M" + d.y + "," + d.x
				+ "L" + (0.5 * (d.parent.y + d.y)) + "," + d.x
				+ " " + (d.parent.y + 20) + "," + d.parent.x
			//+ " " + d.parent.y + "," + d.parent.x;
		};
		return {
			template: '<div qv-extension style="height: 100%; position: relative; overflow: auto;"></div>',
			initialProperties: {
				qHyperCubeDef: {
					qDimensions: [],
					qMeasures: [],
					qInitialDataFetch: []
				}
			},
			definition: {
				type: "items",
				component: "accordion",
				items: {
					measures: {
						uses: "measures",
						min: 1,
						max: 1
					}
				}
			},
			support: {
				snapshot: false,
				export: false,
				exportData: false
			},
			paint: function () {
				//needed for export
				this.$scope.selections = [];
				draw(this.$element[0], this.$scope.getTree());
				return qlik.Promise.resolve();
			},
			controller: ["$scope", "$element", function ($scope) {
				$scope.getTree = function (val) {
					return JSON.parse($scope.layout.qHyperCube.qGrandTotalRow[0].qText);
				};

				$scope.selections = [];

				$scope.sel = function ($event) {
				};
			}]
		};

	});
